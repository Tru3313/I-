
document.addEventListener('DOMContentLoaded', function () {
    console.log('SmartParlay AI loaded');
});
